package com.example.android.ash_udacity_news_app;

public class News {
    private String pillarName;
    private String sectionName;
    private String publishedDate;
    private String webTitle;
    private String webUrl;
    private String name;

    public News(String pillarName, String sectionName, String publicationDate, String webTitle, String webUrl, String name) {
        this.pillarName = pillarName;
        this.sectionName = sectionName;
        this.publishedDate = publicationDate;
        this.webTitle = webTitle;
        this.webUrl = webUrl;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPillarName() {
        return pillarName;
    }

    public void setPillarName(String pillarName) {
        this.pillarName = pillarName;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public String getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(String publishedDate) {
        this.publishedDate = publishedDate;
    }

    public String getWebTitle() {
        return webTitle;
    }

    public void setWebTitle(String webTitle) {
        this.webTitle = webTitle;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }
}
